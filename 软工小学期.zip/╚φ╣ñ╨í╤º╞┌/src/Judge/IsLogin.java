package Judge;

public class IsLogin {
    public void isLogined()
    {
    }
}
